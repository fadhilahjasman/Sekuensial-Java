import static java.lang.System.out;
public class Sekusial02 {

    public static void main(String[] args) {
        int intA;
        int intB,intC;
        intA = 10;
        intB = 20;
        intC = intA + intB;
        out.println(intA+" + "+intB+" = "+intC);
        
    }
    
}