import static java.lang.System.out;

public class Sekuensial03 {

      public static void main(String[] args) {
          out.println("2+3 = "+2+3);
          out.println("2+3 = "+(2+3));
          out.println("2-3 = "+(2-3));
          out.println("2*3 = "+(2*3));
          out.println("1. 2/3 = "+(2/3));
          out.println("2. 2/3 = "+(2f/3f));
          out.println("3. 2/3 = "+(2/3f));
          out.println("4. 2/3 = "+(2f/3));
          out.println("5. 2/3 = "+((float)2/3));
          out.println("6. 2/3 = "+(2/3.0));
          out.println("25/3 = "+(25/3));
          out.println("25%3 = "+(20%3));
          out.println("3/25 = "+(3/25));
          out.println("3%25 = "+(3%25));    
    }
}
