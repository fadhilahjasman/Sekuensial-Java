
package sekuensialjava;
import static java.lang.System.out;

public class SekuensialJava {
    
    public static void main(String[] args) {
    System.out.println("              Selamat Datang ");
        System.out.print  ("     Nama Saya Fadhilah \n\n ");
        System.out.print  ("     Dikelas Algoritma dan Pemrograman \n\n");
        System.out.print  ("  Program Studi :");
        System.out.print  (" Teknik Informatika \n");
        System.out.print  ("  Fakultas Sains dan Teknologi Informasi\n");
        System.out.print  ("Institut Sains Dan Teknologi Nasional Jakarta\n");
        System.out.println("                Tahun 2019");
    }
    
}
